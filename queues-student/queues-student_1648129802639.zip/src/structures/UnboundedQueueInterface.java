package structures;

public interface UnboundedQueueInterface<T> {

}
